package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.WhiteboardBlock
import com.example.model.WhiteboardDoc
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class WhiteboardRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Debes iniciar sesión con Google para acceder a tus pizarrones.")
    }

    fun observeWhiteboards(userId: String): Flow<List<WhiteboardDoc>> = flow {
        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank() || uid != userId) {
            emit(emptyList())
            return@flow
        }
        val path = "users/$userId/whiteboards"
        emitAll(
            db.collection("users").document(userId).collection("whiteboards")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        WhiteboardDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createWhiteboard(
        userId: String,
        title: String,
        prompt: String,
        narration: String,
        blocks: List<WhiteboardBlock>
    ): Result<String> {
        var docPath = "users/$userId/whiteboards"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Sesión cambiada; escritura rechazada." }

            val cleanTitle = title.trim().ifEmpty { "Pizarrón sin título" }.take(200)
            val cleanPrompt = prompt.trim().ifEmpty { cleanTitle }.take(1000)
            val cleanNarration = narration.trim().take(10000)
            val cleanBlocks = blocks.take(40).map { it.toFirestoreMap() }

            val docRef = db.collection("users").document(uid)
                .collection("whiteboards").document()
            docPath = docRef.path

            val payload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "prompt" to cleanPrompt,
                "narration" to cleanNarration,
                "blocks" to cleanBlocks,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateWhiteboard(
        userId: String,
        boardId: String,
        title: String,
        prompt: String,
        narration: String,
        blocks: List<WhiteboardBlock>
    ): Result<Unit> {
        var docPath = "users/$userId/whiteboards/$boardId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Sesión cambiada; actualización rechazada." }
            require(boardId.isNotBlank()) { "El ID del pizarrón no puede estar vacío." }

            val cleanTitle = title.trim().ifEmpty { "Pizarrón sin título" }.take(200)
            val cleanPrompt = prompt.trim().ifEmpty { cleanTitle }.take(1000)
            val cleanNarration = narration.trim().take(10000)
            val cleanBlocks = blocks.take(40).map { it.toFirestoreMap() }

            val docRef = db.collection("users").document(uid)
                .collection("whiteboards").document(boardId)
            docPath = docRef.path

            docRef.update(
                mapOf(
                    "title" to cleanTitle,
                    "prompt" to cleanPrompt,
                    "narration" to cleanNarration,
                    "blocks" to cleanBlocks,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteWhiteboard(userId: String, boardId: String): Result<Unit> {
        var docPath = "users/$userId/whiteboards/$boardId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Sesión cambiada; eliminación rechazada." }
            require(boardId.isNotBlank()) { "El ID del pizarrón no puede estar vacío." }

            val docRef = db.collection("users").document(uid)
                .collection("whiteboards").document(boardId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }
}
