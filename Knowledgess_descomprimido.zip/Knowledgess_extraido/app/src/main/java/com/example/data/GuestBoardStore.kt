package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.WhiteboardBlock
import com.example.model.WhiteboardDoc
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Date
import java.util.UUID

private const val TAG = "GuestBoardStore"

class GuestBoardStore(context: Context) {
    private val storageFile = File(context.applicationContext.filesDir, "guest_boards.json")
    private val _boards = MutableStateFlow(loadFromDisk())

    fun observeBoards(): Flow<List<WhiteboardDoc>> = _boards.asStateFlow()

    suspend fun createBoard(
        title: String,
        prompt: String,
        narration: String,
        blocks: List<WhiteboardBlock>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val id = "guest_${UUID.randomUUID()}"
            val nowSec = System.currentTimeMillis() / 1000L
            val newDoc = WhiteboardDoc(
                id = id,
                userId = "guest",
                title = title.trim().ifEmpty { "Pizarrón sin título" }.take(200),
                prompt = prompt.trim().ifEmpty { title }.take(1000),
                narration = narration.trim().take(10000),
                blocks = blocks.take(40).map { it.toFirestoreMap() },
                createdAt = Timestamp(Date(nowSec * 1000L)),
                updatedAt = Timestamp(Date(nowSec * 1000L))
            )
            val updated = listOf(newDoc) + _boards.value
            saveToDisk(updated)
            _boards.value = updated
            Result.success(id)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save guest board", e)
            Result.failure(e)
        }
    }

    suspend fun updateBoard(
        boardId: String,
        title: String,
        prompt: String,
        narration: String,
        blocks: List<WhiteboardBlock>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val now = Timestamp(Date())
            val updated = _boards.value.map { doc ->
                if (doc.id == boardId) {
                    doc.copy(
                        title = title.trim().ifEmpty { "Pizarrón sin título" }.take(200),
                        prompt = prompt.trim().ifEmpty { title }.take(1000),
                        narration = narration.trim().take(10000),
                        blocks = blocks.take(40).map { it.toFirestoreMap() },
                        updatedAt = now
                    )
                } else {
                    doc
                }
            }.sortedByDescending { it.updatedAt?.seconds ?: 0L }
            saveToDisk(updated)
            _boards.value = updated
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update guest board", e)
            Result.failure(e)
        }
    }

    suspend fun deleteBoard(boardId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val updated = _boards.value.filterNot { it.id == boardId }
            saveToDisk(updated)
            _boards.value = updated
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete guest board", e)
            Result.failure(e)
        }
    }

    private fun loadFromDisk(): List<WhiteboardDoc> {
        if (!storageFile.exists()) return emptyList()
        return try {
            val raw = storageFile.readText()
            if (raw.isBlank()) return emptyList()
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val blocksArr = obj.optJSONArray("blocks") ?: JSONArray()
                    val blocksList = buildList {
                        for (j in 0 until blocksArr.length()) {
                            val b = blocksArr.optJSONObject(j) ?: continue
                            val itemsArr = b.optJSONArray("items") ?: JSONArray()
                            val items = (0 until itemsArr.length()).map { itemsArr.optString(it) }
                            add(
                                mapOf<String, Any?>(
                                    "kind" to b.optString("kind", "highlight"),
                                    "heading" to b.optString("heading", ""),
                                    "items" to items,
                                    "accent" to b.optString("accent", "purple"),
                                    "extra" to b.optString("extra", "")
                                )
                            )
                        }
                    }
                    val createdMs = obj.optLong("createdMs", System.currentTimeMillis())
                    val updatedMs = obj.optLong("updatedMs", createdMs)
                    add(
                        WhiteboardDoc(
                            id = obj.optString("id", ""),
                            userId = "guest",
                            title = obj.optString("title", ""),
                            prompt = obj.optString("prompt", ""),
                            narration = obj.optString("narration", ""),
                            blocks = blocksList,
                            createdAt = Timestamp(Date(createdMs)),
                            updatedAt = Timestamp(Date(updatedMs))
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load guest boards", e)
            emptyList()
        }
    }

    private fun saveToDisk(boards: List<WhiteboardDoc>) {
        val arr = JSONArray()
        boards.forEach { doc ->
            val blocksArr = JSONArray()
            doc.blocks.forEach { block ->
                val itemsArr = JSONArray()
                (block["items"] as? List<*>)?.forEach { item ->
                    itemsArr.put(item?.toString().orEmpty())
                }
                blocksArr.put(
                    JSONObject().apply {
                        put("kind", block["kind"]?.toString().orEmpty())
                        put("heading", block["heading"]?.toString().orEmpty())
                        put("items", itemsArr)
                        put("accent", block["accent"]?.toString().orEmpty())
                        put("extra", block["extra"]?.toString().orEmpty())
                    }
                )
            }
            arr.put(
                JSONObject().apply {
                    put("id", doc.id)
                    put("title", doc.title)
                    put("prompt", doc.prompt)
                    put("narration", doc.narration)
                    put("blocks", blocksArr)
                    put("createdMs", doc.createdAt?.toDate()?.time ?: System.currentTimeMillis())
                    put("updatedMs", doc.updatedAt?.toDate()?.time ?: System.currentTimeMillis())
                }
            )
        }
        storageFile.writeText(arr.toString())
    }
}
