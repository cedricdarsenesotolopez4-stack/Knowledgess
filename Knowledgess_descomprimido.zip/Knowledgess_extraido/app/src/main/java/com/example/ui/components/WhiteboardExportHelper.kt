package com.example.ui.components

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.model.BlockKind
import com.example.model.WhiteboardContent
import java.io.File
import java.io.FileOutputStream

object WhiteboardExportHelper {

    fun exportAndSaveBoard(context: Context, board: WhiteboardContent): Result<String> {
        return try {
            val bitmap = renderBoardToBitmap(context, board)
            val safeName = "Knowledgess_${System.currentTimeMillis()}.png"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_PICTURES}/Knowledgess"
                    )
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("No se pudo crear el archivo en la galería.")
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                Result.success("Pizarrón guardado en Imágenes/Knowledgess")
            } else {
                // Zero-permission export via Share Sheet on API < 29
                val dir = File(context.cacheDir, "boards").apply { mkdirs() }
                val file = File(dir, safeName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(
                    Intent.createChooser(shareIntent, "Compartir pizarrón").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
                Result.success("Pizarrón listo para guardar o compartir")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun renderBoardToBitmap(context: Context, board: WhiteboardContent): Bitmap {
        val width = 1080
        val height = 1920
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Dotted paper background
        canvas.drawColor(Color.parseColor("#F8F7FC"))
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E1DDEB")
        }
        val spacing = 44f
        var x = spacing * 0.5f
        while (x < width) {
            var y = spacing * 0.5f
            while (y < height) {
                canvas.drawCircle(x, y, 3.2f, dotPaint)
                y += spacing
            }
            x += spacing
        }

        val displayTypeface = ResourcesCompat.getFont(context, R.font.kalam) ?: Typeface.DEFAULT_BOLD
        val noteTypeface = ResourcesCompat.getFont(context, R.font.patrick_hand) ?: Typeface.DEFAULT

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#241D3D")
            textSize = 70f
            typeface = Typeface.create(displayTypeface, Typeface.BOLD)
        }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#241D3D")
            textSize = 42f
            typeface = noteTypeface
        }
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8B72FF")
            strokeWidth = 9f
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        var cursorY = 120f
        val marginX = 72f
        val contentWidth = (width - marginX * 2).toInt()

        // Title
        val titleLayout = StaticLayout.Builder.obtain(
            board.title,
            0,
            board.title.length,
            titlePaint,
            contentWidth
        ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

        canvas.save()
        canvas.translate(marginX, cursorY)
        titleLayout.draw(canvas)
        canvas.restore()
        cursorY += titleLayout.height + 16f

        canvas.drawLine(marginX, cursorY, width - marginX * 1.4f, cursorY, accentPaint)
        cursorY += 48f

        // Render blocks
        val boxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#241D3D")
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#AAFFE066")
            style = Paint.Style.FILL
        }

        for (block in board.blocks) {
            if (cursorY > height - 160f) break

            if (block.kind == BlockKind.HIGHLIGHT && block.heading.isNotBlank()) {
                canvas.drawRoundRect(
                    RectF(marginX - 8f, cursorY + 12f, width - marginX * 2f, cursorY + 58f),
                    18f,
                    18f,
                    highlightPaint
                )
            }

            if (block.heading.isNotBlank()) {
                val headLayout = StaticLayout.Builder.obtain(
                    block.heading,
                    0,
                    block.heading.length,
                    bodyPaint,
                    contentWidth
                ).build()
                canvas.save()
                canvas.translate(marginX, cursorY)
                headLayout.draw(canvas)
                canvas.restore()
                cursorY += headLayout.height + 14f
            }

            if (block.kind == BlockKind.VENN && block.items.size >= 2) {
                val cy = cursorY + 130f
                val cx = width * 0.5f
                val r = 110f
                val yellow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D9FACC15") }
                val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC2563EB") }
                val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC16A34A") }
                canvas.drawCircle(cx - 58f, cy, r, yellow)
                canvas.drawCircle(cx + 58f, cy, r, blue)
                canvas.drawOval(RectF(cx - 46f, cy - 90f, cx + 46f, cy + 90f), green)
                canvas.drawCircle(cx - 58f, cy, r, boxStroke)
                canvas.drawCircle(cx + 58f, cy, r, boxStroke)
                cursorY += 270f
            }

            block.items.forEach { item ->
                if (cursorY > height - 120f) return@forEach
                val line = "• $item"
                val lineLayout = StaticLayout.Builder.obtain(
                    line,
                    0,
                    line.length,
                    bodyPaint,
                    contentWidth - 24
                ).build()
                canvas.save()
                canvas.translate(marginX + 16f, cursorY)
                lineLayout.draw(canvas)
                canvas.restore()
                cursorY += lineLayout.height + 10f
            }
            cursorY += 28f
        }

        // Brand footer
        val footerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8C84A6")
            textSize = 30f
            typeface = noteTypeface
        }
        canvas.drawText("Knowledgess", marginX, height - 48f, footerPaint)

        return bitmap
    }
}
