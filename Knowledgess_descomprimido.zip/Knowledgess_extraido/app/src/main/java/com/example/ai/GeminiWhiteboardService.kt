package com.example.ai

import android.graphics.Bitmap
import android.util.Log
import com.example.model.BlockAccent
import com.example.model.BlockKind
import com.example.model.WhiteboardBlock
import com.example.model.WhiteboardContent
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiWhiteboard"

class GeminiWhiteboardService {

    private val blockSchema = Schema.obj(
        properties = mapOf(
            "kind" to Schema.string(
                description = "One of: venn, flow, callout, highlight, steps, comparison."
            ),
            "heading" to Schema.string(
                description = "Short handwritten heading or formula for this block."
            ),
            "items" to Schema.array(
                items = Schema.string(),
                description = "Concise labels or nodes. For 'venn': [LeftCircleLabel, RightCircleLabel, IntersectionLabel, BottomCalloutLabel, SatelliteTag]. For 'flow': 2-4 sequential steps. For 'steps': 2-4 numbered steps. For 'comparison': pairs like 'Concepto: detalle'. For 'callout'/'highlight': 1-2 short lines."
            ),
            "accent" to Schema.string(
                description = "Marker color accent: purple, yellow, blue, green, red, or orange."
            ),
            "extra" to Schema.string(
                description = "Optional short caption or annotation note."
            )
        ),
        optionalProperties = listOf("extra")
    )

    private val whiteboardSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(
                description = "Engaging, concise handwritten whiteboard title in the user's language (e.g., Spanish)."
            ),
            "narration" to Schema.string(
                description = "Friendly, clear spoken teacher explanation (2-4 sentences) suitable for text-to-speech."
            ),
            "blocks" to Schema.array(
                items = blockSchema,
                description = "3 to 6 visual diagram/flowchart/callout/highlight blocks that explain the topic clearly on a sketch whiteboard."
            )
        )
    )

    private val systemPrompt = """
        Eres Knowledgess, un profesor visual creativo que explica cualquier tema dibujando en un pizarrón blanco con marcadores de colores.
        Responde SIEMPRE en el idioma en que pregunta el usuario (por defecto español, amigable, claro y didáctico).
        Diseña explicaciones visuales usando distintos bloques:
        - 'venn': ideal cuando dos o más conceptos se cruzan o interactúan. Pon 3 a 5 elementos cortos en 'items': [CírculoIzquierdo, CírculoDerecho, IntersecciónCentro, EtiquetaInferior, EtiquetaSatélite].
        - 'flow': diagrama de flujo horizontal con flechas (2 a 4 cajas cortas en 'items', ej: ["Gen H activo", "Base H lista", "Se añade A o B"]).
        - 'callout': fórmula clave o advertencia llamativa en color (ej: accent 'red', heading "hh => Sin base H").
        - 'highlight': idea principal subrayada con marcador amarillo/verde (ej: accent 'yellow').
        - 'steps': pasos numerados dibujados con círculos (2 a 4 pasos cortos).
        - 'comparison': contraste rápido entre dos ideas (2 a 4 puntos breves).
        Mantén los textos muy cortos y visuales para que luzcan como apuntes escritos a mano en un pizarrón.
    """.trimIndent()

    private val structuredModel by lazy {
        val config = generationConfig {
            responseMimeType = "application/json"
            responseSchema = whiteboardSchema
            temperature = 0.7f
        }
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = config,
            systemInstruction = content("system") {
                text(systemPrompt)
            }
        )
    }

    private val fallbackModel by lazy {
        Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    suspend fun explainOnWhiteboard(
        prompt: String,
        attachedImage: Bitmap? = null,
        existingBoard: WhiteboardContent? = null,
        isFollowUp: Boolean = false
    ): WhiteboardContent {
        val effectivePrompt = buildString {
            if (isFollowUp && existingBoard != null) {
                append("El usuario ya está viendo el pizarrón titulado \"${existingBoard.title}\" ")
                append("que nació de la pregunta: \"${existingBoard.prompt}\". ")
                append("Bloques actuales: ")
                existingBoard.blocks.forEach { block ->
                    append("[${block.kind.name}: ${block.heading} -> ${block.items.joinToString(", ")}] ")
                }
                append("\n")
                if (prompt.isBlank()) {
                    append("El usuario presionó 'Seguir'. Continúa profundizando la explicación con 2 a 4 bloques nuevos visuales (ejemplos, casos especiales, pasos siguientes o resumen clave) que complementen lo anterior sin repetirlo.")
                } else {
                    append("Nueva pregunta de seguimiento del usuario sobre este mismo pizarrón: $prompt. Genera de 2 a 4 bloques visuales nuevos que respondan esta duda conectando con el tema.")
                }
            } else {
                append(prompt.ifBlank { "Explica lo que aparece en esta imagen paso a paso en el pizarrón." })
            }
        }

        val scaledBitmap = attachedImage?.let { scaleBitmapForUpload(it) }
        val inputContent = content {
            if (scaledBitmap != null) {
                image(scaledBitmap)
            }
            text(effectivePrompt)
        }

        val rawText = try {
            withTimeout(45_000L) {
                structuredModel.generateContent(inputContent).text
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini structured generation timed out", e)
            throw IllegalStateException("La explicación tardó demasiado. Revisa tu conexión e intenta de nuevo.")
        } catch (e: CancellationException) {
            throw e
        } catch (primaryError: Exception) {
            Log.w(TAG, "Structured model failed, attempting plain fallback", primaryError)
            try {
                val fallbackPrompt = """
                    $systemPrompt

                    Devuelve ÚNICAMENTE un JSON válido con esta estructura:
                    {"title":"...","narration":"...","blocks":[{"kind":"highlight","heading":"...","items":["..."],"accent":"yellow","extra":""}]}

                    Solicitud del usuario: $effectivePrompt
                """.trimIndent()
                val fallbackContent = content {
                    if (scaledBitmap != null) image(scaledBitmap)
                    text(fallbackPrompt)
                }
                withTimeout(45_000L) {
                    fallbackModel.generateContent(fallbackContent).text
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini fallback generation timed out", e)
                throw IllegalStateException("La explicación tardó demasiado. Revisa tu conexión e intenta de nuevo.")
            } catch (e: CancellationException) {
                throw e
            } catch (fallbackError: Exception) {
                Log.e(TAG, "Gemini whiteboard generation failed", fallbackError)
                val detail = fallbackError.localizedMessage ?: primaryError.localizedMessage
                throw IllegalStateException(
                    if (!detail.isNullOrBlank()) {
                        "No se pudo obtener respuesta de Gemini: $detail"
                    } else {
                        "No se pudo conectar con Gemini en este momento."
                    }
                )
            }
        }

        if (rawText.isNullOrBlank()) {
            throw IllegalStateException("Gemini devolvió una respuesta vacía.")
        }

        return parseResponseJson(
            rawText = rawText,
            originalPrompt = prompt.ifBlank { existingBoard?.prompt ?: "Consulta visual" },
            existingBoard = if (isFollowUp) existingBoard else null
        )
    }

    private fun parseResponseJson(
        rawText: String,
        originalPrompt: String,
        existingBoard: WhiteboardContent?
    ): WhiteboardContent {
        val cleaned = extractJsonCandidate(rawText)
        return try {
            val json = JSONObject(cleaned)
            val title = json.optString("title", "").trim()
                .ifEmpty { existingBoard?.title ?: "Explicación en el pizarrón" }
            val narration = json.optString("narration", "").trim()
            val blocksArray = json.optJSONArray("blocks")
            val newBlocks = buildList {
                if (blocksArray != null) {
                    for (i in 0 until blocksArray.length()) {
                        val obj = blocksArray.optJSONObject(i) ?: continue
                        val itemsJson = obj.optJSONArray("items")
                        val items = buildList {
                            if (itemsJson != null) {
                                for (j in 0 until itemsJson.length()) {
                                    val text = itemsJson.optString(j, "").trim()
                                    if (text.isNotEmpty()) add(text)
                                }
                            }
                        }
                        add(
                            WhiteboardBlock(
                                kind = BlockKind.fromRaw(obj.optString("kind")),
                                heading = obj.optString("heading", "").trim(),
                                items = items,
                                accent = BlockAccent.fromRaw(obj.optString("accent")),
                                extra = obj.optString("extra", "").trim()
                            )
                        )
                    }
                }
            }.ifEmpty {
                listOf(
                    WhiteboardBlock(
                        kind = BlockKind.HIGHLIGHT,
                        heading = title,
                        items = listOf(narration.ifBlank { rawText.take(240) }),
                        accent = BlockAccent.YELLOW
                    )
                )
            }

            mergeWithExisting(title, narration, newBlocks, originalPrompt, existingBoard)
        } catch (e: Exception) {
            Log.w(TAG, "Falling back to plain-text whiteboard parsing", e)
            val lines = rawText.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val title = existingBoard?.title ?: originalPrompt.take(80)
            val fallbackBlocks = listOf(
                WhiteboardBlock(
                    kind = BlockKind.HIGHLIGHT,
                    heading = lines.firstOrNull()?.take(120) ?: title,
                    items = lines.drop(1).take(6).ifEmpty { listOf(rawText.take(300)) },
                    accent = BlockAccent.YELLOW
                )
            )
            mergeWithExisting(title, rawText.take(600), fallbackBlocks, originalPrompt, existingBoard)
        }
    }

    private fun mergeWithExisting(
        title: String,
        narration: String,
        newBlocks: List<WhiteboardBlock>,
        originalPrompt: String,
        existingBoard: WhiteboardContent?
    ): WhiteboardContent {
        if (existingBoard != null) {
            val combinedBlocks = (existingBoard.blocks + newBlocks).take(40)
            val combinedNarration = listOf(existingBoard.narration, narration)
                .filter { it.isNotBlank() }
                .joinToString(" ")
            return existingBoard.copy(
                narration = combinedNarration,
                blocks = combinedBlocks
            )
        }
        return WhiteboardContent(
            title = title,
            prompt = originalPrompt,
            narration = narration,
            blocks = newBlocks
        )
    }

    private fun extractJsonCandidate(raw: String): String {
        val trimmed = raw.trim()
        val withoutFences = if (trimmed.startsWith("```")) {
            trimmed
                .removePrefix("```json")
                .removePrefix("```JSON")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()
        } else {
            trimmed
        }
        val start = withoutFences.indexOf('{')
        val end = withoutFences.lastIndexOf('}')
        return if (start >= 0 && end > start) {
            withoutFences.substring(start, end + 1)
        } else {
            withoutFences
        }
    }

    private fun scaleBitmapForUpload(bitmap: Bitmap): Bitmap {
        val maxDimension = 1280
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = maxDimension.toFloat() / maxOf(width, height).toFloat()
        val targetW = (width * ratio).toInt().coerceAtLeast(1)
        val targetH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }
}
