package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KnowledgessColorScheme = lightColorScheme(
    primary = MascotPurple,
    onPrimary = ChromeLight,
    primaryContainer = MascotPurpleSoft,
    onPrimaryContainer = InkPrimary,
    secondary = ChromeDark,
    onSecondary = ChromeLight,
    secondaryContainer = BoardSurfaceElevated,
    onSecondaryContainer = InkPrimary,
    tertiary = MarkerYellow,
    onTertiary = InkPrimary,
    background = BoardBackground,
    onBackground = InkPrimary,
    surface = BoardSurface,
    onSurface = InkPrimary,
    surfaceVariant = BoardSurfaceElevated,
    onSurfaceVariant = InkSecondary,
    outline = InkMuted,
    error = MarkerCoral,
    onError = ChromeLight
)

@Composable
fun KnowledgessTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KnowledgessColorScheme,
        typography = Typography,
        content = content
    )
}
