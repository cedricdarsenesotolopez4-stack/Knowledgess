package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.auth.onGoogleSignInClicked
import com.example.auth.signOut
import com.example.model.WhiteboardContent
import com.example.model.WhiteboardDoc
import com.example.ui.components.DottedWhiteboardBackground
import com.example.ui.components.HandDrawnArrowToAvatar
import com.example.ui.components.KnowledgessMascotAvatar
import com.example.ui.components.WhiteboardBlockView
import com.example.ui.components.WhiteboardExportHelper
import com.example.ui.components.WhiteboardTitleWithUnderline
import com.example.ui.theme.BoardSurfaceElevated
import com.example.ui.theme.ChromeDark
import com.example.ui.theme.ChromeLight
import com.example.ui.theme.HandwrittenDisplayFont
import com.example.ui.theme.HandwrittenNoteFont
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.MarkerCoral
import com.example.ui.theme.MascotPurple
import com.example.ui.theme.MascotPurpleSoft
import com.example.viewmodel.BoardUiState
import com.example.viewmodel.HistoryUiState
import com.example.viewmodel.WhiteboardViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.DateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WhiteboardScreen(
    viewModel: WhiteboardViewModel,
    onExitGuestMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val boardState by viewModel.boardState.collectAsStateWithLifecycle()
    val historyState by viewModel.historyState.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    var questionText by remember { mutableStateOf("") }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var audioEnabled by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var revealedBlockCount by remember { mutableIntStateOf(0) }

    var showHistorySheet by remember { mutableStateOf(false) }
    var showPhotoSourceSheet by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    // Back gesture clears active board or closes open modal
    val activeContent: WhiteboardContent? = when (val s = boardState) {
        is BoardUiState.Content -> s.board
        is BoardUiState.Error -> s.previousBoard
        else -> null
    }
    BackHandler(enabled = activeContent != null || showHistorySheet || showPhotoSourceSheet) {
        when {
            showPhotoSourceSheet -> showPhotoSourceSheet = false
            showHistorySheet -> showHistorySheet = false
            else -> viewModel.clearBoard()
        }
    }

    // Text-to-Speech setup for Spanish whiteboard narration
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember(context) {
        var instance: TextToSpeech? = null
        instance = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val esResult = instance?.setLanguage(Locale("es", "MX"))
                if (esResult == TextToSpeech.LANG_MISSING_DATA ||
                    esResult == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    instance?.setLanguage(Locale.getDefault())
                }
                ttsReady = true
            }
        }
        instance
    }

    DisposableEffect(tts) {
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissBanner()
        }
    }

    // Animate block reveal + speak narration when board content updates
    val currentBoardKey = activeContent?.let { "${it.boardId}_${it.blocks.size}_${it.title}" }
    LaunchedEffect(currentBoardKey, isPlaying) {
        val board = activeContent
        if (board == null) {
            revealedBlockCount = 0
            tts.stop()
            return@LaunchedEffect
        }
        if (!isPlaying) {
            tts.stop()
            return@LaunchedEffect
        }
        val total = board.blocks.size
        if (revealedBlockCount == 0 && total > 0) {
            revealedBlockCount = 1
        }
        while (revealedBlockCount < total && isPlaying) {
            delay(180L)
            revealedBlockCount += 1
        }
    }

    LaunchedEffect(currentBoardKey, audioEnabled, isPlaying, ttsReady) {
        val board = activeContent
        if (board != null && audioEnabled && isPlaying && ttsReady && board.narration.isNotBlank()) {
            tts.speak(board.narration, TextToSpeech.QUEUE_FLUSH, null, currentBoardKey ?: "board")
        } else {
            tts.stop()
        }
    }

    // Photo Picker (Zero-permission Android Photo Picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            loadBitmapFromUri(context, uri)?.let { bmp ->
                attachedBitmap = bmp
            }
        }
    }

    // Camera capture via FileProvider
    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraUri
        if (success && uri != null) {
            loadBitmapFromUri(context, uri)?.let { bmp ->
                attachedBitmap = bmp
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = createTempImageUri(context)
            pendingCameraUri = uri
            takePictureLauncher.launch(uri)
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Permiso de cámara denegado. Puedes elegir una imagen de tu galería.")
            }
        }
    }

    // Voice recognition launcher
    val voiceRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val spoken = matches?.firstOrNull()?.trim().orEmpty()
        if (spoken.isNotEmpty()) {
            questionText = spoken
            viewModel.askQuestion(spoken, attachedBitmap)
            questionText = ""
            attachedBitmap = null
        }
    }

    val launchVoiceInput: () -> Unit = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Pregunta lo que quieras…")
        }
        try {
            voiceRecognizerLauncher.launch(intent)
        } catch (_: Exception) {
            scope.launch {
                snackbarHostState.showSnackbar("El reconocimiento de voz no está disponible en este dispositivo.")
            }
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchVoiceInput()
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Permiso de micrófono necesario para dictar tu pregunta.")
            }
        }
    }

    DottedWhiteboardBackground(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                WhiteboardTopBar(
                    hasActiveBoard = activeContent != null,
                    audioEnabled = audioEnabled,
                    isPlaying = isPlaying,
                    onClearClick = {
                        tts.stop()
                        attachedBitmap = null
                        questionText = ""
                        viewModel.clearBoard()
                    },
                    onDownloadClick = {
                        val board = activeContent
                        if (board == null) {
                            scope.launch {
                                snackbarHostState.showSnackbar("Primero genera un pizarrón para descargarlo.")
                            }
                        } else {
                            WhiteboardExportHelper.exportAndSaveBoard(context, board)
                                .onSuccess { msg ->
                                    scope.launch { snackbarHostState.showSnackbar(msg) }
                                }
                                .onFailure { err ->
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            err.localizedMessage ?: "No se pudo guardar el pizarrón."
                                        )
                                    }
                                }
                        }
                    },
                    onToggleAudio = {
                        audioEnabled = !audioEnabled
                        if (!audioEnabled) tts.stop()
                    },
                    onTogglePlayPause = {
                        isPlaying = !isPlaying
                        if (!isPlaying) tts.stop()
                    },
                    onHistoryClick = { showHistorySheet = true }
                )
            },
            bottomBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                ) {
                    // "Seguir" floating action pill above input bar when board is displayed
                    val showFollowUp = boardState is BoardUiState.Content
                    if (showFollowUp) {
                        val isAppending = (boardState as? BoardUiState.Content)?.isAppendingFollowUp == true
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color.White.copy(alpha = 0.88f),
                                tonalElevation = 2.dp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable(enabled = !isAppending) {
                                        viewModel.followUp()
                                    }
                                    .testTag("follow_up_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    if (isAppending) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp,
                                            color = InkPrimary
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Rounded.Send,
                                            contentDescription = null,
                                            tint = InkPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(R.string.action_follow_up),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = InkPrimary
                                    )
                                }
                            }
                        }
                    }

                    // Attached image preview chip
                    AnimatedVisibility(visible = attachedBitmap != null) {
                        attachedBitmap?.let { bmp ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(horizontal = 20.dp, vertical = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color.White)
                                    .border(1.dp, InkMuted.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                                    .padding(6.dp)
                            ) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Imagen lista para explicar",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = InkPrimary
                                )
                                IconButton(
                                    onClick = { attachedBitmap = null },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = stringResource(R.string.cd_remove_attachment),
                                        tint = InkSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    WhiteboardBottomInputBar(
                        text = questionText,
                        hasActiveBoard = activeContent != null,
                        isBusy = boardState is BoardUiState.Loading ||
                            (boardState as? BoardUiState.Content)?.isAppendingFollowUp == true,
                        onTextChange = { questionText = it },
                        onAttachImageClick = { showPhotoSourceSheet = true },
                        onSendClick = {
                            focusManager.clearFocus()
                            val prompt = questionText.trim()
                            val bmp = attachedBitmap
                            if (prompt.isNotEmpty() || bmp != null) {
                                isPlaying = true
                                viewModel.askQuestion(prompt, bmp)
                                questionText = ""
                                attachedBitmap = null
                            }
                        },
                        onVoiceClick = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                launchVoiceInput()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter
            ) {
                when (val state = boardState) {
                    BoardUiState.Empty -> {
                        EmptyWhiteboardView(
                            onQuickTopic = { topic ->
                                isPlaying = true
                                viewModel.askQuestion(topic)
                            }
                        )
                    }

                    is BoardUiState.Loading -> {
                        LoadingWhiteboardView(prompt = state.prompt)
                    }

                    is BoardUiState.Content -> {
                        ActiveWhiteboardCanvas(
                            board = state.board,
                            revealedCount = revealedBlockCount.coerceAtLeast(1)
                        )
                    }

                    is BoardUiState.Error -> {
                        ErrorWhiteboardView(
                            message = state.message,
                            previousBoard = state.previousBoard,
                            onRetry = {
                                isPlaying = true
                                viewModel.retryLastQuestion()
                            },
                            onRestorePrevious = {
                                state.previousBoard?.let { viewModel.restoreBoard(it) }
                                    ?: viewModel.clearBoard()
                            }
                        )
                    }
                }
            }
        }
    }

    // History Modal Sheet ("Pizarrones anteriores")
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color.White
        ) {
            HistorySheetContent(
                historyState = historyState,
                isGuestMode = viewModel.isGuestMode,
                userEmail = Firebase.auth.currentUser?.email.orEmpty(),
                onSelectBoard = { doc ->
                    isPlaying = true
                    viewModel.openSavedBoard(doc)
                    showHistorySheet = false
                },
                onDeleteBoard = { doc ->
                    viewModel.deleteSavedBoard(doc.id)
                },
                onConnectGoogle = {
                    val cm = CredentialManager.create(context)
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = cm,
                        onAuthSuccess = {
                            showHistorySheet = false
                        },
                        onAuthError = { msg ->
                            scope.launch { snackbarHostState.showSnackbar(msg) }
                        },
                        scope = scope
                    )
                },
                onSignOut = {
                    tts.stop()
                    showHistorySheet = false
                    if (viewModel.isGuestMode) {
                        onExitGuestMode()
                    } else {
                        val cm = CredentialManager.create(context)
                        signOut(cm, scope)
                    }
                }
            )
        }
    }

    // Camera or Gallery Modal Sheet
    if (showPhotoSourceSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPhotoSourceSheet = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = stringResource(R.string.photo_source_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = InkPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))
                ListItem(
                    headlineContent = { Text(stringResource(R.string.photo_take)) },
                    leadingContent = {
                        Icon(
                            imageVector = Icons.Rounded.CameraAlt,
                            contentDescription = null,
                            tint = MascotPurple
                        )
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable {
                            showPhotoSourceSheet = false
                            val hasCam = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasCam) {
                                val uri = createTempImageUri(context)
                                pendingCameraUri = uri
                                takePictureLauncher.launch(uri)
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        }
                )
                ListItem(
                    headlineContent = { Text(stringResource(R.string.photo_pick)) },
                    leadingContent = {
                        Icon(
                            imageVector = Icons.Rounded.PhotoLibrary,
                            contentDescription = null,
                            tint = MascotPurple
                        )
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable {
                            showPhotoSourceSheet = false
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun WhiteboardTopBar(
    hasActiveBoard: Boolean,
    audioEnabled: Boolean,
    isPlaying: Boolean,
    onClearClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onToggleAudio: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onHistoryClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircleActionButton(
            icon = Icons.Rounded.Close,
            contentDesc = stringResource(R.string.cd_clear_board),
            testTag = "clear_board_button",
            onClick = onClearClick,
            enabled = true
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleActionButton(
                icon = Icons.Rounded.Download,
                contentDesc = stringResource(R.string.cd_download_board),
                testTag = "download_board_button",
                onClick = onDownloadClick,
                enabled = hasActiveBoard
            )
            CircleActionButton(
                icon = if (audioEnabled) {
                    Icons.AutoMirrored.Rounded.VolumeUp
                } else {
                    Icons.AutoMirrored.Rounded.VolumeOff
                },
                contentDesc = stringResource(R.string.cd_toggle_audio),
                testTag = "toggle_audio_button",
                onClick = onToggleAudio,
                enabled = true
            )
            CircleActionButton(
                icon = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDesc = stringResource(R.string.cd_play_pause),
                testTag = "play_pause_button",
                onClick = onTogglePlayPause,
                enabled = true
            )
            KnowledgessMascotAvatar(
                onClick = onHistoryClick,
                contentDesc = stringResource(R.string.cd_history_mascot),
                size = 48.dp
            )
        }
    }
}

@Composable
private fun CircleActionButton(
    icon: ImageVector,
    contentDesc: String,
    testTag: String,
    onClick: () -> Unit,
    enabled: Boolean
) {
    val bgColor = if (enabled) ChromeDark else ChromeDark.copy(alpha = 0.72f)
    val iconTint = if (enabled) ChromeLight else ChromeLight.copy(alpha = 0.45f)
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(bgColor)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = contentDesc }
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDesc,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EmptyWhiteboardView(
    onQuickTopic: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 600.dp)
            .padding(horizontal = 24.dp)
    ) {
        // Curved arrow + "psst, todos tus pizarrones anteriores están aquí"
        HandDrawnArrowToAvatar(
            hintText = stringResource(R.string.history_hint_arrow),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 6.dp, end = 4.dp)
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.empty_board_prompt),
                fontFamily = HandwrittenDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 31.sp,
                lineHeight = 39.sp,
                color = InkPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(28.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    "El fenotipo Bombay",
                    "¿Cómo funciona la fotosíntesis?",
                    "Teorema de Pitágoras"
                ).forEach { suggestion ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .border(
                                1.2.dp,
                                MascotPurple.copy(alpha = 0.35f),
                                RoundedCornerShape(20.dp)
                            )
                            .clickable { onQuickTopic(suggestion) }
                    ) {
                        Text(
                            text = suggestion,
                            fontFamily = HandwrittenNoteFont,
                            fontSize = 16.sp,
                            color = InkSecondary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingWhiteboardView(prompt: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            color = MascotPurple,
            strokeWidth = 3.5.dp,
            modifier = Modifier.size(44.dp)
        )
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = "Dibujando en el pizarrón…",
            fontFamily = HandwrittenDisplayFont,
            fontWeight = FontWeight.Bold,
            fontSize = 25.sp,
            color = InkPrimary
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "“$prompt”",
            fontFamily = HandwrittenNoteFont,
            fontSize = 18.sp,
            color = InkSecondary,
            textAlign = TextAlign.Center,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ActiveWhiteboardCanvas(
    board: WhiteboardContent,
    revealedCount: Int
) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 640.dp)
            .verticalScroll(scrollState)
            .padding(horizontal = 24.dp, vertical = 10.dp)
    ) {
        WhiteboardTitleWithUnderline(title = board.title)
        Spacer(modifier = Modifier.height(14.dp))

        board.blocks.forEachIndexed { index, block ->
            WhiteboardBlockView(
                block = block,
                visible = index < revealedCount || revealedCount == 0
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
private fun ErrorWhiteboardView(
    message: String,
    previousBoard: WhiteboardContent?,
    onRetry: () -> Unit,
    onRestorePrevious: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            color = MarkerCoral.copy(alpha = 0.1f),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "No pudimos dibujar este pizarrón",
                    fontFamily = HandwrittenDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = MarkerCoral,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (previousBoard != null) {
                        TextButton(onClick = onRestorePrevious) {
                            Text(
                                text = "Volver al pizarrón",
                                color = InkSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    TextButton(onClick = onRetry) {
                        Text(
                            text = "Intentar de nuevo",
                            color = MascotPurple,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WhiteboardBottomInputBar(
    text: String,
    hasActiveBoard: Boolean,
    isBusy: Boolean,
    onTextChange: (String) -> Unit,
    onAttachImageClick: () -> Unit,
    onSendClick: () -> Unit,
    onVoiceClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Dark pill input container
        Row(
            modifier = Modifier
                .weight(1f)
                .height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(ChromeDark)
                .padding(start = 18.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (text.isEmpty()) {
                    Text(
                        text = stringResource(
                            if (hasActiveBoard) R.string.input_placeholder_followup
                            else R.string.input_placeholder_empty
                        ),
                        color = Color.White.copy(alpha = 0.55f),
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = text,
                    onValueChange = onTextChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        color = ChromeLight,
                        fontSize = 16.sp
                    ),
                    cursorBrush = SolidColor(MascotPurple),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (!isBusy) onSendClick() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("question_input")
                )
            }

            IconButton(
                onClick = onAttachImageClick,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("attach_image_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.CameraAlt,
                    contentDescription = stringResource(R.string.cd_attach_image),
                    tint = ChromeLight,
                    modifier = Modifier.size(22.dp)
                )
            }

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ChromeLight)
                    .clickable(enabled = !isBusy, onClick = onSendClick)
                    .semantics { contentDescription = "Enviar pregunta" }
                    .testTag("send_question_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Send,
                    contentDescription = stringResource(R.string.cd_send_question),
                    tint = ChromeDark,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Separate circular microphone button on the right
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(ChromeDark)
                .clickable(enabled = !isBusy, onClick = onVoiceClick)
                .semantics { contentDescription = "Preguntar por voz" }
                .testTag("voice_input_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = stringResource(R.string.cd_voice_input),
                tint = ChromeLight,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun HistorySheetContent(
    historyState: HistoryUiState,
    isGuestMode: Boolean,
    userEmail: String,
    onSelectBoard: (WhiteboardDoc) -> Unit,
    onDeleteBoard: (WhiteboardDoc) -> Unit,
    onConnectGoogle: () -> Unit,
    onSignOut: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.history_title),
                    fontFamily = HandwrittenDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    color = InkPrimary
                )
                Text(
                    text = if (isGuestMode) {
                        stringResource(R.string.guest_mode_label)
                    } else {
                        userEmail.ifBlank { "Cuenta conectada" }
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = InkMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (isGuestMode) {
                TextButton(
                    onClick = onConnectGoogle,
                    modifier = Modifier.testTag("connect_google_button")
                ) {
                    Text(
                        text = stringResource(R.string.guest_connect_google),
                        color = MascotPurple,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                TextButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("sign_out_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                        contentDescription = null,
                        tint = MarkerCoral,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.history_sign_out),
                        color = MarkerCoral
                    )
                }
            }
        }

        if (isGuestMode) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onSignOut,
                    modifier = Modifier.testTag("exit_guest_button")
                ) {
                    Text(
                        text = stringResource(R.string.guest_exit),
                        color = InkSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        HorizontalDivider(color = BoardSurfaceElevated)
        Spacer(modifier = Modifier.height(8.dp))

        when (historyState) {
            HistoryUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MascotPurple)
                }
            }

            is HistoryUiState.Error -> {
                Text(
                    text = historyState.message,
                    color = MarkerCoral,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }

            is HistoryUiState.Success -> {
                if (historyState.boards.isEmpty()) {
                    Text(
                        text = stringResource(R.string.history_empty),
                        fontFamily = HandwrittenNoteFont,
                        fontSize = 19.sp,
                        color = InkSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp)
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.height(380.dp)
                    ) {
                        items(historyState.boards, key = { it.id }) { doc ->
                            val formattedDate = remember(doc.updatedAt, doc.createdAt) {
                                val ts = doc.updatedAt ?: doc.createdAt
                                ts?.toDate()?.let {
                                    DateFormat.getDateTimeInstance(
                                        DateFormat.SHORT,
                                        DateFormat.SHORT
                                    ).format(it)
                                } ?: "Reciente"
                            }
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MascotPurpleSoft.copy(alpha = 0.45f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .clickable { onSelectBoard(doc) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = doc.title,
                                            fontFamily = HandwrittenDisplayFont,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 20.sp,
                                            color = InkPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${doc.prompt} • $formattedDate",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = InkSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteBoard(doc) },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.DeleteOutline,
                                            contentDescription = "Eliminar pizarrón",
                                            tint = InkMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun createTempImageUri(context: Context): Uri {
    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
    val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

@Suppress("DEPRECATION")
private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (e: Exception) {
        Toast.makeText(context, "No se pudo leer la imagen.", Toast.LENGTH_SHORT).show()
        null
    }
}
