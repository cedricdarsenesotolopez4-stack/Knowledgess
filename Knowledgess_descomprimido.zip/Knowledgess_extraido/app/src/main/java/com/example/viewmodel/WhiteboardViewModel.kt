package com.example.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiWhiteboardService
import com.example.data.GuestBoardStore
import com.example.data.WhiteboardRepository
import com.example.model.WhiteboardContent
import com.example.model.WhiteboardDoc
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "WhiteboardVM"

sealed interface HistoryUiState {
    data object Loading : HistoryUiState
    data class Success(val boards: List<WhiteboardDoc>) : HistoryUiState
    data class Error(val message: String) : HistoryUiState
}

sealed interface BoardUiState {
    data object Empty : BoardUiState
    data class Loading(val prompt: String) : BoardUiState
    data class Content(
        val board: WhiteboardContent,
        val isAppendingFollowUp: Boolean = false
    ) : BoardUiState
    data class Error(
        val message: String,
        val previousBoard: WhiteboardContent? = null
    ) : BoardUiState
}

class WhiteboardViewModel(
    private val repository: WhiteboardRepository?,
    private val guestStore: GuestBoardStore?,
    private val aiService: GeminiWhiteboardService,
    private val currentUserId: String?
) : ViewModel() {

    val isGuestMode: Boolean
        get() = currentUserId.isNullOrBlank() || repository == null

    private var lastAttemptedPrompt: String = ""
    private var lastAttemptedBitmap: Bitmap? = null

    val historyState: StateFlow<HistoryUiState> = run {
        val sourceFlow = when {
            !currentUserId.isNullOrBlank() && repository != null ->
                repository.observeWhiteboards(currentUserId)
            guestStore != null ->
                guestStore.observeBoards()
            else ->
                flowOf(emptyList())
        }
        sourceFlow
            .map<List<WhiteboardDoc>, HistoryUiState> { HistoryUiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing whiteboards", rootError)
                emit(HistoryUiState.Error(rootError.localizedMessage ?: "Error al cargar pizarrones"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = HistoryUiState.Loading
            )
    }

    private val _boardState = MutableStateFlow<BoardUiState>(BoardUiState.Empty)
    val boardState: StateFlow<BoardUiState> = _boardState.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun askQuestion(prompt: String, attachedImage: Bitmap? = null) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty() && attachedImage == null) return

        lastAttemptedPrompt = trimmed
        lastAttemptedBitmap = attachedImage

        val activeBoard = currentActiveBoard()
        val isContinuingActive = activeBoard != null && attachedImage == null &&
            activeBoard.boardId != null

        viewModelScope.launch {
            if (isContinuingActive) {
                _boardState.value = BoardUiState.Content(activeBoard, isAppendingFollowUp = true)
            } else {
                _boardState.value = BoardUiState.Loading(trimmed.ifEmpty { "Analizando imagen..." })
            }

            try {
                val generated = aiService.explainOnWhiteboard(
                    prompt = trimmed,
                    attachedImage = attachedImage,
                    existingBoard = if (isContinuingActive) activeBoard else null,
                    isFollowUp = isContinuingActive
                )
                // Show generated whiteboard immediately without waiting for network persistence
                _boardState.value = BoardUiState.Content(generated)
                launchPersistence(generated)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "askQuestion failed", e)
                _boardState.value = BoardUiState.Error(
                    message = e.localizedMessage ?: "No se pudo generar el pizarrón.",
                    previousBoard = activeBoard
                )
            }
        }
    }

    fun retryLastQuestion() {
        if (lastAttemptedPrompt.isNotBlank() || lastAttemptedBitmap != null) {
            askQuestion(lastAttemptedPrompt, lastAttemptedBitmap)
        } else {
            _boardState.value = BoardUiState.Empty
        }
    }

    fun restoreBoard(board: WhiteboardContent) {
        _boardState.value = BoardUiState.Content(board)
    }

    fun followUp(customPrompt: String = "") {
        val activeBoard = currentActiveBoard() ?: return
        viewModelScope.launch {
            _boardState.value = BoardUiState.Content(activeBoard, isAppendingFollowUp = true)
            try {
                val generated = aiService.explainOnWhiteboard(
                    prompt = customPrompt.trim(),
                    attachedImage = null,
                    existingBoard = activeBoard,
                    isFollowUp = true
                )
                _boardState.value = BoardUiState.Content(generated)
                launchPersistence(generated)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "followUp failed", e)
                _statusBanner.value = e.localizedMessage ?: "No se pudo continuar la explicación."
                _boardState.value = BoardUiState.Content(activeBoard, isAppendingFollowUp = false)
            }
        }
    }

    fun openSavedBoard(doc: WhiteboardDoc) {
        _boardState.value = BoardUiState.Content(
            WhiteboardContent(
                boardId = doc.id,
                title = doc.title,
                prompt = doc.prompt,
                narration = doc.narration,
                blocks = doc.parsedBlocks()
            )
        )
    }

    fun clearBoard() {
        _boardState.value = BoardUiState.Empty
    }

    fun deleteSavedBoard(boardId: String) {
        viewModelScope.launch {
            val result = if (!currentUserId.isNullOrBlank() && repository != null) {
                repository.deleteWhiteboard(currentUserId, boardId)
            } else {
                guestStore?.deleteBoard(boardId) ?: Result.success(Unit)
            }
            result.onFailure { error ->
                _statusBanner.value = error.localizedMessage ?: "No se pudo eliminar el pizarrón."
            }
            val current = currentActiveBoard()
            if (current?.boardId == boardId && result.isSuccess) {
                _boardState.value = BoardUiState.Empty
            }
        }
    }

    private fun currentActiveBoard(): WhiteboardContent? = when (val state = _boardState.value) {
        is BoardUiState.Content -> state.board
        is BoardUiState.Error -> state.previousBoard
        else -> null
    }

    private fun launchPersistence(content: WhiteboardContent) {
        viewModelScope.launch {
            val updated = persistBoard(content)
            val current = currentActiveBoard()
            if (current != null &&
                current.boardId == null &&
                updated.boardId != null &&
                current.title == updated.title
            ) {
                val isAppending = (_boardState.value as? BoardUiState.Content)?.isAppendingFollowUp == true
                _boardState.value = BoardUiState.Content(updated, isAppendingFollowUp = isAppending)
            }
        }
    }

    private suspend fun persistBoard(content: WhiteboardContent): WhiteboardContent {
        val existingId = content.boardId
        if (!currentUserId.isNullOrBlank() && repository != null) {
            if (existingId.isNullOrBlank()) {
                val createResult = repository.createWhiteboard(
                    userId = currentUserId,
                    title = content.title,
                    prompt = content.prompt,
                    narration = content.narration,
                    blocks = content.blocks
                )
                return createResult.fold(
                    onSuccess = { newId -> content.copy(boardId = newId) },
                    onFailure = { err ->
                        _statusBanner.value = "Guardado en nube pendiente: ${err.localizedMessage ?: "error"}"
                        content
                    }
                )
            } else {
                val updateResult = repository.updateWhiteboard(
                    userId = currentUserId,
                    boardId = existingId,
                    title = content.title,
                    prompt = content.prompt,
                    narration = content.narration,
                    blocks = content.blocks
                )
                updateResult.onFailure { err ->
                    _statusBanner.value = "No se pudo actualizar en nube: ${err.localizedMessage ?: "error"}"
                }
                return content
            }
        } else if (guestStore != null) {
            if (existingId.isNullOrBlank()) {
                return guestStore.createBoard(
                    title = content.title,
                    prompt = content.prompt,
                    narration = content.narration,
                    blocks = content.blocks
                ).fold(
                    onSuccess = { newId -> content.copy(boardId = newId) },
                    onFailure = { content }
                )
            } else {
                guestStore.updateBoard(
                    boardId = existingId,
                    title = content.title,
                    prompt = content.prompt,
                    narration = content.narration,
                    blocks = content.blocks
                )
                return content
            }
        }
        return content
    }
}
