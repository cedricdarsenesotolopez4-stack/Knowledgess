package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.ai.GeminiWhiteboardService
import com.example.auth.AuthScreen
import com.example.data.GuestBoardStore
import com.example.data.WhiteboardRepository
import com.example.firebase.configureAppCheck
import com.example.ui.screens.WhiteboardScreen
import com.example.ui.theme.KnowledgessTheme
import com.example.viewmodel.WhiteboardViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            KnowledgessTheme {
                AppContent()
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
    }
}

@Composable
fun AppContent() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var isGuestMode by rememberSaveable { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
            if (auth.currentUser != null) {
                isGuestMode = false
            }
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    when {
        user != null -> {
            val uid = user.uid
            key(uid) {
                val viewModel: WhiteboardViewModel = viewModel(
                    key = uid,
                    factory = viewModelFactory {
                        initializer {
                            val app = checkNotNull(this[APPLICATION_KEY]) {
                                "APPLICATION_KEY missing from CreationExtras"
                            }
                            val databaseId = app.getString(R.string.firestore_database_id)
                            val db = FirebaseFirestore.getInstance(databaseId)
                            WhiteboardViewModel(
                                repository = WhiteboardRepository(db),
                                guestStore = null,
                                aiService = GeminiWhiteboardService(),
                                currentUserId = uid
                            )
                        }
                    }
                )
                WhiteboardScreen(
                    viewModel = viewModel,
                    onExitGuestMode = {}
                )
            }
        }

        isGuestMode -> {
            key("guest") {
                val viewModel: WhiteboardViewModel = viewModel(
                    key = "guest",
                    factory = viewModelFactory {
                        initializer {
                            val app = checkNotNull(this[APPLICATION_KEY]) {
                                "APPLICATION_KEY missing from CreationExtras"
                            }
                            WhiteboardViewModel(
                                repository = null,
                                guestStore = GuestBoardStore(app),
                                aiService = GeminiWhiteboardService(),
                                currentUserId = null
                            )
                        }
                    }
                )
                WhiteboardScreen(
                    viewModel = viewModel,
                    onExitGuestMode = { isGuestMode = false }
                )
            }
        }

        else -> {
            AuthScreen(
                onAuthSuccess = { currentUser = Firebase.auth.currentUser },
                onContinueAsGuest = { isGuestMode = true }
            )
        }
    }
}
