package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BoardBackground = Color(0xFFF8F7FC)
val BoardDotColor = Color(0xFFE1DDEB)
val BoardSurface = Color(0xFFFFFFFF)
val BoardSurfaceElevated = Color(0xFFF1EFF9)

val InkPrimary = Color(0xFF241D3D)
val InkSecondary = Color(0xFF5F567B)
val InkMuted = Color(0xFF8C84A6)

val ChromeDark = Color(0xFF16161C)
val ChromeDarkElevated = Color(0xFF23232D)
val ChromeLight = Color(0xFFFFFFFF)

val MascotPurple = Color(0xFF7B61FF)
val MascotPurpleSoft = Color(0xFFEDE9FE)
val SketchPurple = Color(0xFF8B72FF)

val MarkerYellow = Color(0xFFFACC15)
val MarkerYellowHighlight = Color(0xAAFFE066)
val MarkerBlue = Color(0xFF2563EB)
val MarkerGreen = Color(0xFF16A34A)
val MarkerCoral = Color(0xFFEF4444)
val MarkerOrange = Color(0xFFF97316)
val MarkerMint = Color(0xAA6EE7B7)
