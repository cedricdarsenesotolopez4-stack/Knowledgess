package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class BlockKind {
    VENN,
    FLOW,
    CALLOUT,
    HIGHLIGHT,
    STEPS,
    COMPARISON;

    companion object {
        fun fromRaw(raw: String?): BlockKind {
            val normalized = raw?.trim()?.uppercase()
            return entries.firstOrNull { it.name == normalized } ?: HIGHLIGHT
        }
    }
}

enum class BlockAccent {
    PURPLE,
    YELLOW,
    BLUE,
    GREEN,
    RED,
    ORANGE;

    companion object {
        fun fromRaw(raw: String?): BlockAccent {
            val normalized = raw?.trim()?.uppercase()
            return entries.firstOrNull { it.name == normalized } ?: PURPLE
        }
    }
}

data class WhiteboardBlock(
    val kind: BlockKind = BlockKind.HIGHLIGHT,
    val heading: String = "",
    val items: List<String> = emptyList(),
    val accent: BlockAccent = BlockAccent.PURPLE,
    val extra: String = ""
) {
    fun toFirestoreMap(): Map<String, Any> = mapOf(
        "kind" to kind.name.lowercase(),
        "heading" to heading.take(240),
        "items" to items.take(12).map { it.take(300) },
        "accent" to accent.name.lowercase(),
        "extra" to extra.take(300)
    )

    companion object {
        fun fromFirestoreMap(raw: Map<String, Any?>): WhiteboardBlock {
            val rawItems = (raw["items"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            return WhiteboardBlock(
                kind = BlockKind.fromRaw(raw["kind"] as? String),
                heading = (raw["heading"] as? String).orEmpty(),
                items = rawItems,
                accent = BlockAccent.fromRaw(raw["accent"] as? String),
                extra = (raw["extra"] as? String).orEmpty()
            )
        }
    }
}

@Keep
@IgnoreExtraProperties
data class WhiteboardDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val prompt: String = "",
    val narration: String = "",
    val blocks: List<Map<String, Any?>> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun parsedBlocks(): List<WhiteboardBlock> =
        blocks.map { WhiteboardBlock.fromFirestoreMap(it) }
}

data class WhiteboardContent(
    val boardId: String? = null,
    val title: String = "",
    val prompt: String = "",
    val narration: String = "",
    val blocks: List<WhiteboardBlock> = emptyList()
)
