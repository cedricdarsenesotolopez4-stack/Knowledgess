package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BlockAccent
import com.example.model.BlockKind
import com.example.model.WhiteboardBlock
import com.example.ui.theme.BoardBackground
import com.example.ui.theme.BoardDotColor
import com.example.ui.theme.ChromeDark
import com.example.ui.theme.HandwrittenDisplayFont
import com.example.ui.theme.HandwrittenNoteFont
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.MarkerBlue
import com.example.ui.theme.MarkerCoral
import com.example.ui.theme.MarkerGreen
import com.example.ui.theme.MarkerMint
import com.example.ui.theme.MarkerOrange
import com.example.ui.theme.MarkerYellow
import com.example.ui.theme.MarkerYellowHighlight
import com.example.ui.theme.MascotPurple
import com.example.ui.theme.SketchPurple

@Composable
fun DottedWhiteboardBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .background(BoardBackground)
            .drawBehind {
                val spacing = 22.dp.toPx()
                val dotRadius = 1.6.dp.toPx()
                var x = spacing * 0.5f
                while (x < size.width) {
                    var y = spacing * 0.5f
                    while (y < size.height) {
                        drawCircle(
                            color = BoardDotColor,
                            radius = dotRadius,
                            center = Offset(x, y)
                        )
                        y += spacing
                    }
                    x += spacing
                }
            }
    ) {
        content()
    }
}

@Composable
fun KnowledgessMascotAvatar(
    onClick: () -> Unit,
    contentDesc: String,
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(ChromeDark)
            .clickable(onClick = onClick)
            .semantics { contentDescription = contentDesc }
            .testTag("history_mascot_button"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size - 6.dp)) {
            val w = this.size.width
            val h = this.size.height
            drawCircle(color = Color.White, radius = w * 0.47f)

            val body = Path().apply {
                moveTo(w * 0.22f, h * 0.85f)
                lineTo(w * 0.22f, h * 0.35f)
                quadraticTo(w * 0.25f, h * 0.12f, w * 0.38f, h * 0.24f)
                quadraticTo(w * 0.50f, h * 0.19f, w * 0.62f, h * 0.24f)
                quadraticTo(w * 0.75f, h * 0.12f, w * 0.78f, h * 0.35f)
                lineTo(w * 0.78f, h * 0.85f)
                close()
            }
            drawPath(body, color = MascotPurple)

            // White oval eyes
            drawOval(
                color = Color.White,
                topLeft = Offset(w * 0.29f, h * 0.35f),
                size = Size(w * 0.17f, h * 0.24f)
            )
            drawOval(
                color = Color.White,
                topLeft = Offset(w * 0.54f, h * 0.35f),
                size = Size(w * 0.17f, h * 0.24f)
            )
            // Pupils
            drawCircle(
                color = ChromeDark,
                radius = w * 0.052f,
                center = Offset(w * 0.39f, h * 0.48f)
            )
            drawCircle(
                color = ChromeDark,
                radius = w * 0.052f,
                center = Offset(w * 0.64f, h * 0.48f)
            )
        }
    }
}

@Composable
fun HandDrawnArrowToAvatar(
    hintText: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End
    ) {
        // Curly hand-drawn arrow pointing up-right to mascot
        Canvas(
            modifier = Modifier
                .width(58.dp)
                .height(48.dp)
                .padding(end = 12.dp)
        ) {
            val w = size.width
            val h = size.height
            val curve = Path().apply {
                moveTo(w * 0.12f, h * 0.92f)
                cubicTo(
                    w * 0.48f, h * 0.75f,
                    w * 0.22f, h * 0.40f,
                    w * 0.45f, h * 0.48f
                )
                cubicTo(
                    w * 0.72f, h * 0.58f,
                    w * 0.75f, h * 0.22f,
                    w * 0.80f, h * 0.08f
                )
            }
            drawPath(
                path = curve,
                color = InkSecondary,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            // Arrowhead
            val head = Path().apply {
                moveTo(w * 0.63f, h * 0.22f)
                lineTo(w * 0.81f, h * 0.06f)
                lineTo(w * 0.92f, h * 0.28f)
            }
            drawPath(
                path = head,
                color = InkSecondary,
                style = Stroke(width = 4.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
        Text(
            text = hintText,
            fontFamily = HandwrittenNoteFont,
            fontSize = 19.sp,
            lineHeight = 23.sp,
            color = InkSecondary,
            textAlign = TextAlign.End
        )
    }
}

@Composable
fun WhiteboardTitleWithUnderline(
    title: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            fontFamily = HandwrittenDisplayFont,
            fontWeight = FontWeight.Bold,
            fontSize = 31.sp,
            lineHeight = 36.sp,
            color = InkPrimary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .height(8.dp)
        ) {
            val path = Path().apply {
                moveTo(0f, size.height * 0.6f)
                quadraticTo(
                    size.width * 0.52f,
                    size.height * 0.1f,
                    size.width,
                    size.height * 0.5f
                )
            }
            drawPath(
                path = path,
                color = SketchPurple,
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun WhiteboardBlockView(
    block: WhiteboardBlock,
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) +
            slideInVertically(initialOffsetY = { it / 5 }),
        modifier = modifier
    ) {
        when (block.kind) {
            BlockKind.VENN -> VennDiagramBlock(block)
            BlockKind.FLOW -> FlowRowBlock(block)
            BlockKind.CALLOUT -> CalloutFormulaBlock(block)
            BlockKind.HIGHLIGHT -> HighlightNoteBlock(block)
            BlockKind.STEPS -> StepsBlock(block)
            BlockKind.COMPARISON -> ComparisonBlock(block)
        }
    }
}

@Composable
private fun VennDiagramBlock(block: WhiteboardBlock) {
    val leftLabel = block.items.getOrNull(0).orEmpty()
    val rightLabel = block.items.getOrNull(1).orEmpty()
    val centerLabel = block.items.getOrNull(2).orEmpty()
    val bottomLabel = block.items.getOrNull(3).orEmpty()
    val satelliteLabel = block.items.getOrNull(4).orEmpty()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (block.heading.isNotBlank()) {
            Text(
                text = block.heading,
                fontFamily = HandwrittenNoteFont,
                fontSize = 18.sp,
                color = InkSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Top labels above Venn circles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(
                text = leftLabel,
                fontFamily = HandwrittenNoteFont,
                fontSize = 19.sp,
                color = InkPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = rightLabel,
                fontFamily = HandwrittenNoteFont,
                fontSize = 19.sp,
                color = InkPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width * 0.52f
                val cy = size.height * 0.52f
                val radius = minOf(size.width, size.height) * 0.36f
                val leftCenter = Offset(cx - radius * 0.52f, cy)
                val rightCenter = Offset(cx + radius * 0.52f, cy)

                // Left Circle (Sunny Yellow)
                drawCircle(
                    color = MarkerYellow.copy(alpha = 0.82f),
                    radius = radius,
                    center = leftCenter
                )
                // Right Circle (Cobalt Blue)
                drawCircle(
                    color = MarkerBlue.copy(alpha = 0.78f),
                    radius = radius,
                    center = rightCenter
                )
                // Overlap tint (Green intersection approximation via oval)
                drawOval(
                    color = MarkerGreen.copy(alpha = 0.78f),
                    topLeft = Offset(cx - radius * 0.42f, cy - radius * 0.83f),
                    size = Size(radius * 0.84f, radius * 1.66f)
                )
                // Hand-drawn outlines
                drawCircle(
                    color = InkPrimary,
                    radius = radius,
                    center = leftCenter,
                    style = Stroke(width = 4.5f)
                )
                drawCircle(
                    color = InkPrimary,
                    radius = radius,
                    center = rightCenter,
                    style = Stroke(width = 4.5f)
                )

                // Optional satellite circle & pointer arrow on left (just like Glóbulo rojo)
                if (satelliteLabel.isNotBlank()) {
                    val satCenter = Offset(leftCenter.x - radius * 0.58f, cy - radius * 0.52f)
                    drawCircle(
                        color = InkPrimary,
                        radius = radius * 0.42f,
                        center = satCenter,
                        style = Stroke(width = 3.5f)
                    )
                    drawLine(
                        color = SketchPurple,
                        start = Offset(satCenter.x - radius * 0.85f, satCenter.y + 4f),
                        end = Offset(satCenter.x - radius * 0.15f, satCenter.y + 4f),
                        strokeWidth = 4f,
                        cap = StrokeCap.Round
                    )
                }
            }

            if (satelliteLabel.isNotBlank()) {
                Text(
                    text = satelliteLabel,
                    fontFamily = HandwrittenNoteFont,
                    fontSize = 15.sp,
                    lineHeight = 17.sp,
                    color = SketchPurple,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 10.dp, top = 26.dp)
                )
            }

            if (centerLabel.isNotBlank()) {
                Text(
                    text = centerLabel,
                    fontFamily = HandwrittenNoteFont,
                    fontSize = 16.sp,
                    lineHeight = 18.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(horizontal = 120.dp)
                        .padding(top = 6.dp)
                )
            }
        }

        if (bottomLabel.isNotBlank()) {
            Text(
                text = bottomLabel,
                fontFamily = HandwrittenNoteFont,
                fontSize = 18.sp,
                color = InkPrimary,
                textAlign = TextAlign.Center
            )
        }
        if (block.extra.isNotBlank()) {
            Text(
                text = block.extra,
                fontFamily = HandwrittenNoteFont,
                fontSize = 15.sp,
                color = InkSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowRowBlock(block: WhiteboardBlock) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        if (block.heading.isNotBlank()) {
            Text(
                text = block.heading,
                fontFamily = HandwrittenNoteFont,
                fontSize = 18.sp,
                color = accentToColor(block.accent)
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            block.items.forEachIndexed { index, step ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .border(
                                width = 1.8.dp,
                                color = InkPrimary,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .background(
                                color = Color.White.copy(alpha = 0.78f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = step,
                            fontFamily = HandwrittenNoteFont,
                            fontSize = 17.sp,
                            color = InkPrimary
                        )
                    }
                    if (index < block.items.lastIndex) {
                        Text(
                            text = " →",
                            fontFamily = HandwrittenDisplayFont,
                            fontSize = 20.sp,
                            color = InkPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalloutFormulaBlock(block: WhiteboardBlock) {
    val color = if (block.accent == BlockAccent.PURPLE) MarkerCoral else accentToColor(block.accent)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        if (block.heading.isNotBlank()) {
            Text(
                text = block.heading,
                fontFamily = HandwrittenDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                lineHeight = 29.sp,
                color = color
            )
        }
        block.items.forEach { line ->
            Text(
                text = line,
                fontFamily = HandwrittenNoteFont,
                fontSize = 19.sp,
                color = color
            )
        }
        if (block.extra.isNotBlank()) {
            Text(
                text = block.extra,
                fontFamily = HandwrittenNoteFont,
                fontSize = 16.sp,
                color = InkSecondary
            )
        }
    }
}

@Composable
private fun HighlightNoteBlock(block: WhiteboardBlock) {
    val markerColor = when (block.accent) {
        BlockAccent.GREEN -> MarkerMint
        BlockAccent.PURPLE -> MascotPurple.copy(alpha = 0.22f)
        else -> MarkerYellowHighlight
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        if (block.heading.isNotBlank()) {
            Box(
                modifier = Modifier
                    .drawBehind {
                        drawRoundRect(
                            color = markerColor,
                            topLeft = Offset(-4f, size.height * 0.28f),
                            size = Size(size.width + 12f, size.height * 0.65f),
                            cornerRadius = CornerRadius(14f, 14f)
                        )
                    }
                    .padding(horizontal = 4.dp)
            ) {
                Text(
                    text = block.heading,
                    fontFamily = HandwrittenDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = InkPrimary
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
        }
        block.items.forEach { line ->
            Text(
                text = "• $line",
                fontFamily = HandwrittenNoteFont,
                fontSize = 19.sp,
                lineHeight = 24.sp,
                color = InkPrimary,
                modifier = Modifier.padding(start = 6.dp, top = 2.dp)
            )
        }
        if (block.extra.isNotBlank()) {
            Text(
                text = block.extra,
                fontFamily = HandwrittenNoteFont,
                fontSize = 16.sp,
                color = InkSecondary,
                modifier = Modifier.padding(start = 6.dp, top = 4.dp)
            )
        }
    }
}

@Composable
private fun StepsBlock(block: WhiteboardBlock) {
    val badgeColor = accentToColor(block.accent)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (block.heading.isNotBlank()) {
            Text(
                text = block.heading,
                fontFamily = HandwrittenDisplayFont,
                fontWeight = FontWeight.Bold,
                fontSize = 21.sp,
                color = InkPrimary
            )
        }
        block.items.forEachIndexed { index, step ->
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .border(2.dp, badgeColor, CircleShape)
                        .background(badgeColor.copy(alpha = 0.14f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${index + 1}",
                        fontFamily = HandwrittenDisplayFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = badgeColor
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = step,
                    fontFamily = HandwrittenNoteFont,
                    fontSize = 19.sp,
                    lineHeight = 24.sp,
                    color = InkPrimary
                )
            }
        }
    }
}

@Composable
private fun ComparisonBlock(block: WhiteboardBlock) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.85f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .border(1.8.dp, InkPrimary.copy(alpha = 0.85f), RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            if (block.heading.isNotBlank()) {
                Text(
                    text = block.heading,
                    fontFamily = HandwrittenDisplayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = accentToColor(block.accent)
                )
                Spacer(modifier = Modifier.height(6.dp))
            }
            block.items.forEach { item ->
                Text(
                    text = "→ $item",
                    fontFamily = HandwrittenNoteFont,
                    fontSize = 18.sp,
                    lineHeight = 23.sp,
                    color = InkPrimary,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

private fun accentToColor(accent: BlockAccent): Color = when (accent) {
    BlockAccent.PURPLE -> MascotPurple
    BlockAccent.YELLOW -> MarkerOrange
    BlockAccent.BLUE -> MarkerBlue
    BlockAccent.GREEN -> MarkerGreen
    BlockAccent.RED -> MarkerCoral
    BlockAccent.ORANGE -> MarkerOrange
}
