const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function buildSamplePayload(uid, timestamp = new Date(Date.now() - 2000)) {
  return {
    userId: uid,
    title: "El fenotipo Bombay",
    prompt: "Explícame el fenotipo Bombay",
    narration: "El fenotipo Bombay ocurre cuando falta el gen H dominante.",
    blocks: [
      {
        kind: "venn",
        heading: "Interacción genética",
        items: ["Genes ABO", "Gen H (H/h)", "Tipo de sangre", "Base H", "Glóbulo rojo"],
        accent: "blue",
        extra: "Sin base H no se expresan A ni B",
      },
      {
        kind: "flow",
        heading: "Gen H activo",
        items: ["Gen H activo", "Base H lista", "Se añade A o B"],
        accent: "purple",
        extra: "",
      },
      {
        kind: "highlight",
        heading: "Fenotipo Bombay",
        items: ["Parece tipo O aunque tenga alelos A o B"],
        accent: "yellow",
        extra: "",
      },
    ],
    createdAt: timestamp,
    updatedAt: timestamp,
  };
}

test("Unauthenticated user: cannot read, list, or write whiteboards", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("whiteboards").get());
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("whiteboards")
      .doc("board_1")
      .set(buildSamplePayload(ALICE_UID))
  );
});

test("Authenticated owner: valid Kotlin create, partial update, list, and delete succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const boardRef = aliceDb.collection("users").doc(ALICE_UID).collection("whiteboards").doc("board_1");

  await assertSucceeds(boardRef.set(buildSamplePayload(ALICE_UID, created)));

  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("whiteboards")
      .orderBy("updatedAt", "desc")
      .get()
  );

  await assertSucceeds(
    boardRef.update({
      title: "El fenotipo Bombay (Ampliado)",
      narration: "Explicación ampliada con seguimiento.",
      blocks: [
        {
          kind: "callout",
          heading: "hh => Sin base H",
          items: ["hh => Sin base H"],
          accent: "red",
          extra: "",
        },
      ],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(boardRef.delete());
});

test("Security bounds: reject extra id field, shadow fields, immutable createdAt change, and future timestamp", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const boards = aliceDb.collection("users").doc(ALICE_UID).collection("whiteboards");

  // Reject @DocumentId `id` inside payload
  await assertFails(
    boards.doc("board_with_id").set({
      id: "board_with_id",
      ...buildSamplePayload(ALICE_UID, created),
    })
  );

  // Reject shadow field
  await assertFails(
    boards.doc("board_shadow").set({
      ...buildSamplePayload(ALICE_UID, created),
      isAdmin: true,
    })
  );

  // Reject future timestamp
  await assertFails(
    boards.doc("board_future").set(buildSamplePayload(ALICE_UID, new Date(Date.now() + 60000)))
  );

  // Reject immutable createdAt mutation on update
  await assertSucceeds(boards.doc("board_valid").set(buildSamplePayload(ALICE_UID, created)));
  await assertFails(
    boards.doc("board_valid").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Cross-user isolation: Bob cannot read, list, update, or delete Alice's whiteboards", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("whiteboards")
      .doc("alice_board")
      .set(buildSamplePayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const aliceBoards = bobDb.collection("users").doc(ALICE_UID).collection("whiteboards");

  await assertFails(aliceBoards.get());
  await assertFails(aliceBoards.doc("alice_board").get());
  await assertFails(aliceBoards.doc("alice_board").update({ title: "Hijacked" }));
  await assertFails(aliceBoards.doc("alice_board").delete());
  await assertFails(
    bobDb
      .collection("users")
      .doc(BOB_UID)
      .collection("whiteboards")
      .doc("spoof_board")
      .set(buildSamplePayload(ALICE_UID))
  );
});
